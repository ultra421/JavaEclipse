package david.elias.Humanoides;

public class Gordo extends Zombie{
	
	public Gordo () { // Damage, Movimineto, Salud, Tipo
		super(1,1,2,"Gordo");
	}

}
