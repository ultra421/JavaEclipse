package david.elias.Humanoides;

public class Corredor extends Zombie {
	
	public Corredor () { // Damage, Movimineto, Salud, Tipo
		super(1,2,1,"Corredor");
	}

}
