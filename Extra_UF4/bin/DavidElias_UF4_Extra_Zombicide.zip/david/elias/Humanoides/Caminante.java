package david.elias.Humanoides;

public class Caminante extends Zombie {
	
	public Caminante () { // Damage, Movimineto, Salud, Tipo
		super(1,1,1,"Caminante");
	}

}
