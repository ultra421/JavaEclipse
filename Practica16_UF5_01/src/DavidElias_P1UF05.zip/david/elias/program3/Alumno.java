package david.elias.program3;

public class Alumno {

	String nombre;
	int edad;
	
	public Alumno (String nombre, int edad) {
		
		this.nombre = nombre;
		this.edad = edad;
		
	}
	
}
