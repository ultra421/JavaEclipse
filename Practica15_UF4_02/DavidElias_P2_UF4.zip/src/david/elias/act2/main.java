package david.elias.act2;

public class main {
	
	public static void main (String [] args) {
		
		Circuito circuito = new Circuito();
		
		circuito.startMenu();
		
	}

}
