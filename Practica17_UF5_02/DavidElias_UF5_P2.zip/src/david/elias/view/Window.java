package david.elias.view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

@SuppressWarnings("serial")
public class Window extends JDialog implements ActionListener {
	
	public Window () {
		
		setSize(500,500);
		setVisible(true);
		buildVentana();
		
	}
	
	public void buildVentana() {
		
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
